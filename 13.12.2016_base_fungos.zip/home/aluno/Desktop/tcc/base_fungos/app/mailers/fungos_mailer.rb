class FungosMailer < ApplicationMailer
end