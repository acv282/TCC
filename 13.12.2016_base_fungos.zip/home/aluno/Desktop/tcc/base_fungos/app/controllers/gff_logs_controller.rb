class GffLogsController < ApplicationController
end
