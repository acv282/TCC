require 'test_helper'

class GffLogTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
