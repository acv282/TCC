class RemoveVersaoFromGbkLogs < ActiveRecord::Migration
  def change
  end
end
