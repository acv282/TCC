class AddIndexToUsersEmail < ActiveRecord::Migration
  def change
  end
end
