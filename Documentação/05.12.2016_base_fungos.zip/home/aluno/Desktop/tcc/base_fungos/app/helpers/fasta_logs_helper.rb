module FastaLogsHelper
end
