class GffLog < ActiveRecord::Base
	belongs_to :organism
end
