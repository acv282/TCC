class FungosMailer < ApplicationMailer
end
