class GbkLogsController < ApplicationController
end
