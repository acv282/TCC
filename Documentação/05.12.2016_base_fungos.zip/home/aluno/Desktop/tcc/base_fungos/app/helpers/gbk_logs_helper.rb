module GbkLogsHelper
end
