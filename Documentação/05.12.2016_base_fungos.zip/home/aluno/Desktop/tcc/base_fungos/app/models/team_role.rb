class TeamRole < ActiveRecord::Base
	
	# Relações
	has_many :teams
	
end
