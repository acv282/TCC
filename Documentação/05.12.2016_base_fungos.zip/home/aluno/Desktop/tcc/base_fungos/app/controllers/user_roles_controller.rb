class UserRolesController < ApplicationController
  def new
  end
end
