class GbkLog < ActiveRecord::Base
	belongs_to :organism
end
