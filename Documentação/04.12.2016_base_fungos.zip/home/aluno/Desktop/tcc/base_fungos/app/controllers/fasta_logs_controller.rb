class FastaLogsController < ApplicationController
end
