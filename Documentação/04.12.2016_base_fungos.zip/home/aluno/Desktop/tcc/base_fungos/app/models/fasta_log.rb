class FastaLog < ActiveRecord::Base
	belongs_to :organism
end
