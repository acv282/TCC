class ApplicationMailer < ActionMailer::Base
	
	default from: "fungos.tcc@gmail.com"
	layout 'mailer'
	
	def email_teste
		mail(to: 'fungos.tcc@gmail.com', subject: 'E-mail de teste')
	end
	
end
