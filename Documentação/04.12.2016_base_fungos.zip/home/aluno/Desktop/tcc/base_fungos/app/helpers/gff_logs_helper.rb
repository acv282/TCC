module GffLogsHelper
end
