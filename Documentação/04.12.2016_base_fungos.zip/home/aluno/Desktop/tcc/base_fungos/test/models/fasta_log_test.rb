require 'test_helper'

class FastaLogTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
