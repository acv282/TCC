require 'test_helper'

class OrganismStatusTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
