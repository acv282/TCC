require 'test_helper'

class TeamRoleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
