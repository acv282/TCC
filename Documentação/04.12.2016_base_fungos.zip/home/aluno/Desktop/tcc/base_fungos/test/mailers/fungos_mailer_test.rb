require 'test_helper'

class FungosMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
