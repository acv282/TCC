require 'test_helper'

class GffLogsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
